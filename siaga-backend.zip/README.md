# 🩺 SIAGA Backend

Backend untuk chatbot AI aplikasi SIAGA.

## 🚀 Cara Menjalankan Lokal
1. Clone repo:
   ```bash
   git clone https://github.com/username/siaga-backend.git
   cd siaga-backend
   ```
2. Install dependensi:
   ```bash
   npm install
   ```
3. Buat file `.env`:
   ```
   OPENAI_API_KEY=masukkan_api_key_openai_anda
   ```
4. Jalankan server:
   ```bash
   npm start
   ```
5. Server berjalan di `http://localhost:3000`

## 🌐 Deploy ke Render
- Hubungkan repo ini ke Render.
- Build Command: `npm install`
- Start Command: `npm start`
- Tambahkan Environment Variable `OPENAI_API_KEY` di Render Dashboard.
